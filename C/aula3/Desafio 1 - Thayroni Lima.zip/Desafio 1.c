#include <stdio.h>

int main(){
	printf("Bem-vindo ao Mundo da Programa��o");
	return 0;
}
