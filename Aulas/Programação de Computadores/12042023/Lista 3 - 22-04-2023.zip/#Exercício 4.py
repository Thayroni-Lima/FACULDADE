#Exercício 4

#Entrada e processamento
y = float(input("Qual é o menor número do seu intervalo?\n"))
z = float(input("Qual é o maior número do seu intervalo?\n"))
x = float(input("Qual número X que você quer verificar:\n"))
if y > z:
    y, z = z, y

#Processamento e saída
if y <= x <= z:
    print("Seu número X está contido no intervalo dado.")
else:
    print("Seu número X não está contido no intervalo dado.")
