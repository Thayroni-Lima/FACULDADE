#Exercício 10

#Entrada
num = int(input("Digite o número a ser verificado:\n"))
cont = 0
x = 1

#Processamento
while x <= num:
    if num % x == 0:
        cont = cont + 1
    x = x + 1

if cont == 2:
    print(f"O número {num} é primo.")
else:
    print(f"O número {num} não é primo.")