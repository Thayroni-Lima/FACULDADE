#Exercício 12

#Entrada
num = int(input("Digite um número\n"))

#Processamento e saída
if num % 3 == 0 or num % 5 == 0:
    print("O número é divisível por 3 ou por 5")
else:
    print("O número não é divisível por 3 nem por 5")
