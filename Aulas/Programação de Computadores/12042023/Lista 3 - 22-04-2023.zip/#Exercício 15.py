#Exercício 15

#Entrada
num = int(input("Digite um número a ser verificado:\n"))


#Processamento
x = 1
per = 0
while x < num:
    if num % x == 0:
        per = per + x
    x = x + 1

#Saída
if per == num:
    print("É um número perfeito.")
else:
    print("Não é um número perfeito.")