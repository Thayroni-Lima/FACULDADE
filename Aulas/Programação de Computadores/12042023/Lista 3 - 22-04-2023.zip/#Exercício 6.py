#Exercício 6

#Entrada
numero = float(input("Digite o número\n"))

#Processamento
if numero > 0:
    numero = "positivo"
elif 0 > numero:
    numero = "negativo"
else:
    numero = "nulo"

#Saída
print("Seu número é", numero)