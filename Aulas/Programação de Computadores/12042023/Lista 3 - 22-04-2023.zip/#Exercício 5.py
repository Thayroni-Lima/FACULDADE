#Exercício 5

#Entrada e processamento
idade = int(input("Qual a sua idade>\n"))

#Processamento e saída
if idade >= 60:
    print("Você é idoso.")
elif 18 <= idade < 60:
    print("Você é adulto.")
elif 12 < idade < 18:
    print("Você é adolescente.")
elif 0 < idade <= 12:
    print("Você é criança.")
else:
    print("Você ainda não nasceu.")
