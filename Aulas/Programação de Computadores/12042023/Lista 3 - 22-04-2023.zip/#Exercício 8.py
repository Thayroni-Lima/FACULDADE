#Exercício 8

#Entrada
altura_usuario = float(input("Qual a sua altura?\n"))
altura_brinquedo = float(input("Qual a altura mínima para entrar no brinquedo?\n"))

#Processamento e saída
if altura_usuario < altura_brinquedo:
    print(f"Sua altura de {altura_usuario} m não permite a entrada no brinquedo.")
else:
    print(f"Sua altura de {altura_usuario} m permite a entrada no brinquedo.")