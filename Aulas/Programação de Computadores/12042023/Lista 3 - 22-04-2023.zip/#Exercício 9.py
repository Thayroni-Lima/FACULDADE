#Exercício 9

#Entrada
divisor = int(input("Qual o divisor?\n"))
dividendo = int(input("Qual o dividendo?\n"))

#Processamento e saída
if divisor % dividendo == 0:
    print(f"O divisor {divisor} é divisível pelo dividendo {dividendo}")
else:
    print(f"O divisor {divisor} é não divisível pelo dividendo {dividendo}")