#Exercício 16

#Entrada
num = int(input("Digite um número\n"))

#Processamento
par = num % 2 == 0
pos = num > 0

if par == False and pos == False:
    print("O número é ímpar e negativo")
elif par == False and pos == True:
    print("O número é ímpar e positivo.")
elif num == 0:
    print("O número é par e nulo.")
elif par == True and pos == False:
    print("O número é par e negativo.")
elif par == True and pos == True:
    print("O número é par e positivo")
