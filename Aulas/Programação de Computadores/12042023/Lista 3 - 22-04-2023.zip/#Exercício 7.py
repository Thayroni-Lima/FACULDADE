#Exercício 7

#Entrada
ano = float(input("Digite o ano a ser verificado\n"))

#Processamento
anoPor4 = ano % 4 == 0
anoPor100 = ano % 100 == 0
anoPor400 = ano % 400 == 0

#Saída
if anoPor4 == False:
    print("Não é bissexto.")
elif anoPor4 == True and anoPor100 == False:
    print("O ano é bissexto.")
elif anoPor4 == True and anoPor100 == True and anoPor400 == False:
    print("Não é bissexto.")
elif  anoPor4 == True and anoPor100 == True and anoPor400 == True:
    print("O ano é bissexto.")