#Exercício 13

#Entrada
num = int(input("Digite o número a ser verificado:\n"))
print("--------------------")
cont = 0
x = 1

#Processamento
while x <= num:
    if num % x == 0:
        cont = cont + 1
    x = x + 1

#saída
if cont == 2:
    print(f"Os divisores são 1 e {num}.")
    print(f"O número {num} é primo.")
else:
    print("Os divisores são mais de 2:")
    cont = 0
    x = 1
    while x <= num:
        if num % x == 0:
            print(x)
            cont = cont + 1
        x = x + 1
    print(f"O número {num} não é primo.")