#Exercício 11

#Entrada
idade = int(input("Qual a sua idade:\n"))

#Processamento
if idade >= 18:
    print("Você tem a idade mínima para poder dirigir legalmente.")
else:
    print("Você ainda não pode dirigir.")