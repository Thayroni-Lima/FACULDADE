#Exercício 14

#Entrada
altura_jogador = float(input("Qual a sua altura?\n"))
altura_minima = float(input("Qual a altura mínima para jogar basquete?\n"))

#Processamento e saída
if altura_jogador < altura_minima:
    print(f"Sua altura de {altura_jogador} m não permite jogar basquete.")
else:
    print(f"Sua altura de {altura_minima} m permite jogar basquete.")