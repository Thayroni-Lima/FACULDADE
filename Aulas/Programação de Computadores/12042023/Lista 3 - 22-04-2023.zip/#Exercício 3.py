#Exercício 3

#Entrada e processamento e saída
alfabetizado = input("Você é alfabetizado?\n")
if alfabetizado != "sim":
    print("Você não é obrigado a votar.")
else:
#Entrada e processamento e saída
    idade = int(input("Qual a sua idade?\n"))
    if 16 <= idade < 18:
        print("Você não é obrigado a votar.")
    elif idade >= 70:
        print("Você não é obrigado a votar.")
    elif idade < 16:
        print("Você ainda não pode votar.")
    else:
        print("Você é obrigado a votar.")