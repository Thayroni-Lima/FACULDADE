#Exercício 2

#Entrada
numero = int(input("Digite o número\n"))

#Processamento e Saída
if numero % 2 == 0:
    print(f"O número {numero} é par.")
elif numero % 2 == 1:
    print(f"O número {numero} é ímpar.")
