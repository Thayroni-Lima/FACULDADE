<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORMULÁRIO 04</title>
</head>
<body>
    <h1>HTML form</h1>

    <form>
    <div class="form-group">
    <label for="exampleInputPassword1">First Name</label>
    <input type="text" class="form-control" id="exampleInputPassword1">

    <form>
    <div class="form-group">
    <label for="exampleInputPassword1">Last Name</label>
    <input type="text" class="form-control" id="exampleInputPassword1">

    <form>
    <div class="form-group">
    <label for="exampleInputPassword1">E-mail</label>
    <input type="email" class="form-control" id="exampleInputPassword1">

    <div><input type="radio">Male</div>
    <div><input type="radio">Female</div>

    <div>
        <button type="submit" class="btn btn-primary">Submit</button>
        <button type="submit" class="btn btn-primary">Reset</button>
    </div>

  </div>

    </form>
</body>
</html>