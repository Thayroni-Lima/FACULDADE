<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FORMULÁRIO 03</title>
</head>
<body>
    <h1 align = "Center">Employee Login Form</h1>


    <form align = "center">
    <div class="form-group">
    <label for="exampleInputPassword1">UserName</label>
    <input type="text" class="form-control" id="exampleInputPassword1">

    <form align = "center">
    <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1">

    <div><button type="submit" class="btn btn-primary">Enviar</button></div>

  </div>

    </form>
</body>
</html>